<?php include  $_SERVER['DOCUMENT_ROOT']."/project/webSub/test1/include/header.php"; ?>
echo "<script>location.href='board_list.php'</script>";
<?php include  $_SERVER['DOCUMENT_ROOT']."/project/webSub/test1/include/footer.php"; ?>