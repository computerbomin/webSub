<footer>
	<section id="footer_in">
		<div id="copyright">
			라일락 서점
		</div>
		<ul id="author">
			<li>저자 문의 메일</li>
			<li>- 메일 주소 : computer@naver.com</li>
		</ul>
	</section>
</footer>